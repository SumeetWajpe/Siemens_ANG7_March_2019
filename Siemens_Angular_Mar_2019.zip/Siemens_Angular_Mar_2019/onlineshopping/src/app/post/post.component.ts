import { Component, OnInit } from '@angular/core';
import { PostsService } from './posts.service';
import { Observable } from 'rxjs';
import { Post } from './post.model';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {

  allPosts:Post[] = [];
//   constructor(public postsServObj:PostsService) { 
//    var observable =  this.postsServObj.getAllPosts();
//    observable.subscribe((response)=>{    
//      console.log(response);
//         this.allPosts = response;
//  });
//   }

constructor(public postsServObj:PostsService) { 
  var aPromise =  this.postsServObj.getAllPosts();
  aPromise.then(
    (response)=> {
      this.allPosts = response;
      this.postsServObj.allPostsFromService = response;
    } ,
    (err)=> console.log(err)
  )
 }

  ngOnInit() {
  }

}

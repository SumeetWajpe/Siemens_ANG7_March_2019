import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';
import { Product } from '../product.model';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
@Input() productdetails:Product = new Product();
@Input() productIndex:number;
@Output() changeLikes:EventEmitter<number> = new EventEmitter<number>()
@Output() deleteProduct:EventEmitter<number> = new EventEmitter<number>()

isFree:boolean=false;
isHighlighted:boolean=false;
  constructor() { }

  ngOnInit() {
  }

  Incrementlikes(){
   // this.productdetails.likes++;
   this.productdetails.likes+=1;
   this.changeLikes.emit(this.productdetails.likes);
  }

  DeleteTheProduct(){
    this.deleteProduct.emit(this.productIndex);
  }

}

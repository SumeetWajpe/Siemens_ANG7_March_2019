import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PostsService } from '../post/posts.service';
import { Post } from '../post/post.model';

@Component({
  selector: 'app-postdetails',
  templateUrl: './postdetails.component.html',
  styleUrls: ['./postdetails.component.css']
})
export class PostdetailsComponent implements OnInit {

  thePost:Post = new Post();
  constructor(public routerService:ActivatedRoute,public postServObj:PostsService) { }

  ngOnInit() {
    this.routerService.params.subscribe(
      p => {
        let thePostId = p.id;
        this.thePost = this.postServObj.allPostsFromService.find(post => post.id == thePostId)
      }
    )
  }

}

import { Component, OnInit } from '@angular/core';
import { Product } from '../product.model';
import { ProductService } from '../product/product.service';

@Component({
  selector: 'app-shoppingcart',
  templateUrl: './shoppingcart.component.html',
  styleUrls: ['./shoppingcart.component.css']
})
export class ShoppingcartComponent  {

  heading:string = "Flipkart";
  companyName:string="";
  productName:string="";

  listOfProducts:Product[] = [];

  constructor(public servObj:ProductService){
        this.listOfProducts = this.servObj.getAllProducts();
  }
ChangeHeading(){
  this.heading = "Amazon";
}


ChangeHeadingOnChange(e){
  this.heading = e.target.value
}

HandlerInParent(theCount){
      console.log(theCount);
}

DeleteProductHandler(theIndex:number){
      this.listOfProducts.splice(theIndex,1);
} 

}

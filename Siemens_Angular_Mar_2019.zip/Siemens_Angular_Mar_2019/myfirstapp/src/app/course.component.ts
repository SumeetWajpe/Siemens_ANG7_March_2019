import {Component, Input} from '@angular/core';
import { Course } from './course.model';

@Component({
    selector:`course`,
    templateUrl:'./course.component.html'   
})
export class CourseComponent{
  @Input()  coursedetails:Course=new Course("React","3 Days");
}

// export function Addition(x,y){
//   return x + y;
// }
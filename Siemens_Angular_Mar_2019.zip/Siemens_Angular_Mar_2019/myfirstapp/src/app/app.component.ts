import { Component } from '@angular/core';
import { Course } from './course.model';

@Component({
  selector: 'root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'myfirstapp';
  headerImage:string = "https://raw.githubusercontent.com/dart-lang/logos/master/logos_and_wordmarks/angulardart-logo.png";
  // course1:Course = new Course("Vue","2 Days");
  // course2:Course =   new Course("Node","3 Days");
  // course3:Course =  new Course("Angular","5 Days");

  courses:Course[] = [
    new Course("Vue","2 Days"),
    new Course("Node","3 Days"),
    new Course("Angular","5 Days"),
    new Course(".NET","5 Days")

  ];

}

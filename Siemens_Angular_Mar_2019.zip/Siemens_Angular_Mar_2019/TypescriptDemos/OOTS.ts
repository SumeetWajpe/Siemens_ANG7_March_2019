
interface ICompany{
    name:string;
    city?:string;
    getSalary?():number;
}
var company:ICompany = {name:'Siemens'};

class Company implements ICompany{
    name:string;
    city:string;

    getSalary(){
        return 400000;
    }
}


// classes

class Car{
    name:string;
    speed:number;       
        constructor(name:string="i20",speed:number=100){
            this.name = name;
            this.speed = speed;
    }
    accelerate():string{
           // return " The Car " + this.name + " is running at " + this.speed + " kmph !";
           return ` The Car ${this.name} is running at ${this.speed} kmph !`;
    }
}

class JamesBondCar extends Car{
        canFly:boolean;
        useNitroPower:boolean;

        constructor(name:string,speed:number,fly:boolean,nitro:boolean){
            super(name,speed);
            this.canFly = fly;
            this.useNitroPower = nitro;
        }

        accelerate():string{
                return super.accelerate() + " Can It Fly ? " + this.canFly;
        }
}
var jbc = new JamesBondCar("Aston Martin",500,true,true);
console.log(jbc.accelerate());


// var carObj = new Car();
// console.log(carObj.accelerate());

// var multiLineString = `First LIne
// Second Line !
// Last LIne !
// `


//enhanced class synatx

class EnhancedCar{
    constructor(public name:string="i20",public speed:number=100){

    }
}


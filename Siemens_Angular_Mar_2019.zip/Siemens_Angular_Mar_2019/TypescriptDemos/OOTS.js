var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var company = { name: 'Siemens' };
var Company = /** @class */ (function () {
    function Company() {
    }
    Company.prototype.getSalary = function () {
        return 400000;
    };
    return Company;
}());
// classes
var Car = /** @class */ (function () {
    function Car(name, speed) {
        if (name === void 0) { name = "i20"; }
        if (speed === void 0) { speed = 100; }
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.accelerate = function () {
        // return " The Car " + this.name + " is running at " + this.speed + " kmph !";
        return " The Car " + this.name + " is running at " + this.speed + " kmph !";
    };
    return Car;
}());
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(name, speed, fly, nitro) {
        var _this = _super.call(this, name, speed) || this;
        _this.canFly = fly;
        _this.useNitroPower = nitro;
        return _this;
    }
    JamesBondCar.prototype.accelerate = function () {
        return _super.prototype.accelerate.call(this) + " Can It Fly ? " + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Aston Martin", 500, true, true);
console.log(jbc.accelerate());
// var carObj = new Car();
// console.log(carObj.accelerate());
// var multiLineString = `First LIne
// Second Line !
// Last LIne !
// `
//enhanced class synatx
var EnhancedCar = /** @class */ (function () {
    function EnhancedCar(name, speed) {
        if (name === void 0) { name = "i20"; }
        if (speed === void 0) { speed = 100; }
        this.name = name;
        this.speed = speed;
    }
    return EnhancedCar;
}());

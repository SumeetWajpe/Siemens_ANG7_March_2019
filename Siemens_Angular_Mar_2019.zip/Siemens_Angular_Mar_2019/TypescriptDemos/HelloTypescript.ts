var x = 100; // type inference !
//x = "Hello !";
var str:string; // type annotation !
str = "Hello Typescript !"

var a:any;
a = 10;
a = "Helllo !!";
a = true;
a = {name:'Sumeet'};
a= [10,20,30];

var booleanVar:boolean;
var i:number;


// Functions !

function Add(x:number,y:number):number|string{
    if(x < 0){
        return "x should be greater than 0 !";
    }
    return x + y;
}

var result:number|string = Add(10,30);
console.log(result);

// let : Block scoped | ES 6

if(true){
    let blockScoped = 20000;

    if(true){
      //  let blockScoped = 40000;
        console.log(blockScoped)
    }
}

// console.log(blockScoped)


const PI = 3.14;
// PI = 3.14565; // Error !


// Arrays 

var cars:string[] = ["BMW","AUDI","FERRARI"];
var moreCars:Array<string> =new Array<string>("TATA","MAHINDRA")
var allCars:string[] = [...cars,...moreCars,"HYUNDAI"];/// Spread Operator !

// for
// for-in

// for(let car in allCars){
//     console.log(car);// index 
// }
// for-of | ES 6
// for(let car of allCars){
//     console.log(car); // element
// }
allCars.forEach(function(car,index){
        console.log(car);
});

var person = {name:'Sachin',city:'Mumbai'};
var player = {...person,runs:50000,city:'Pune'}; // Spread !

console.log(player);

// Destructuring [Arrays / Objects]

// let firstCar,secondCar,thirdCar;
let [firstCar,,secondCar,thirdCar="HONDA"] = cars;


// Parameters
// Optional !

// function PrintBooks(author?:string,title?:string){       
//     console.log(author,title);
// }   


// Default Parameters

function PrintBooks(author:string="Unknown",title:string="Unknown"){       
    console.log(author,title);
}   

PrintBooks();
PrintBooks("Sachin Tendulkar","Playing It My Way");
PrintBooks(undefined,"Dummy");

// function declaration
// function Square(x){
//     return x * x;
// }

// function as an expression !
// var Square = function(x){
//     return x * x;
// }
// Arrow Function

//  var Square = (x) => {
//      return x * x;
//  }

// Or

var Square = x => x * x;

allCars.forEach(function(car,index){
    console.log(car);
});

// OR

allCars.forEach((car:string) => console.log(car))
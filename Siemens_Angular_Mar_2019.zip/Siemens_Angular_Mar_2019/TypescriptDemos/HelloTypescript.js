var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var x = 100; // type inference !
//x = "Hello !";
var str; // type annotation !
str = "Hello Typescript !";
var a;
a = 10;
a = "Helllo !!";
a = true;
a = { name: 'Sumeet' };
a = [10, 20, 30];
var booleanVar;
var i;
// Functions !
function Add(x, y) {
    if (x < 0) {
        return "x should be greater than 0 !";
    }
    return x + y;
}
var result = Add(10, 30);
console.log(result);
// let : Block scoped | ES 6
if (true) {
    var blockScoped = 20000;
    if (true) {
        //  let blockScoped = 40000;
        console.log(blockScoped);
    }
}
// console.log(blockScoped)
var PI = 3.14;
// PI = 3.14565; // Error !
// Arrays 
var cars = ["BMW", "AUDI", "FERRARI"];
var moreCars = new Array("TATA", "MAHINDRA");
var allCars = cars.concat(moreCars, ["HYUNDAI"]); /// Spread Operator !
// for
// for-in
// for(let car in allCars){
//     console.log(car);// index 
// }
// for-of | ES 6
// for(let car of allCars){
//     console.log(car); // element
// }
allCars.forEach(function (car, index) {
    console.log(car);
});
var person = { name: 'Sachin', city: 'Mumbai' };
var player = __assign({}, person, { runs: 50000, city: 'Pune' }); // Spread !
console.log(player);
// Destructuring [Arrays / Objects]
// let firstCar,secondCar,thirdCar;
var firstCar = cars[0], secondCar = cars[2], _a = cars[3], thirdCar = _a === void 0 ? "HONDA" : _a;
// Parameters
// Optional !
function PrintBooks(author, title) {
    console.log(author, title);
}
PrintBooks();

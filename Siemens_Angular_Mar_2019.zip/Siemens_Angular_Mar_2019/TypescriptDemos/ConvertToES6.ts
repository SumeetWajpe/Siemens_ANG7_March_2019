let s:string="GlobalVar";

function Addition(x:any,y:any){
    return x  + y;
}
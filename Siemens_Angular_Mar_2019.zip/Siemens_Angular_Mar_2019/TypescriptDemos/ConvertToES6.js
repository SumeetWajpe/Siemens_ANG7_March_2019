let s = "GlobalVar";
function Addition(x, y) {
    return x + y;
}

import { Component, OnInit,ChangeDetectionStrategy } from '@angular/core';
import { Product } from '../product.model';
import { ProductService } from '../product/product.service';
import { Store } from '@ngrx/store';
import { AppState } from '../state/app.state';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-shoppingcart',
  templateUrl: './shoppingcart.component.html',
  styleUrls: ['./shoppingcart.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush

})
export class ShoppingcartComponent  {

  heading:string = "Flipkart";
  companyName:string="";
  productName:string="";

  listOfProducts:Observable<Product[]> = new Observable<Product[]>();

  // constructor(public servObj:ProductService){
  //       this.listOfProducts = this.servObj.getAllProducts();
  // }

  constructor(public store:Store<AppState>){
    this.listOfProducts = this.store.select("products");
}
ChangeHeading(){
  this.heading = "Amazon";
}


ChangeHeadingOnChange(e){
  this.heading = e.target.value
}

HandlerInParent(theCount){
      console.log(theCount);
}

DeleteProductHandler(theIndex:number){
      //this.listOfProducts.splice(theIndex,1);
} 

}

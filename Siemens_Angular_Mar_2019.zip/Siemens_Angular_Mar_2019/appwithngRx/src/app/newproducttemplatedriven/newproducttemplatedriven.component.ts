import { Component, OnInit } from '@angular/core';
import { Product } from '../product.model';
import { ProductService } from '../product/product.service';

@Component({
  selector: 'app-newproducttemplatedriven',
  templateUrl: './newproducttemplatedriven.component.html',
  styleUrls: ['./newproducttemplatedriven.component.css']
})
export class NewproducttemplatedrivenComponent implements OnInit {
  aNewProduct:Product = new Product();
  constructor(public prodServObj:ProductService) { }

  ngOnInit() {
  }

  AddNewProduct(theForm){
      // var newProduct = Object.assign({},this.aNewProduct);
       

      if(theForm.valid){
        this.prodServObj.insertNewProduct(this.aNewProduct);
        this.aNewProduct = new Product();
        theForm.reset();
      }

  }

}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewproducttemplatedrivenComponent } from './newproducttemplatedriven.component';

describe('NewproducttemplatedrivenComponent', () => {
  let component: NewproducttemplatedrivenComponent;
  let fixture: ComponentFixture<NewproducttemplatedrivenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewproducttemplatedrivenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewproducttemplatedrivenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

export class CourseService{
    allCourses:string[] = ['React','Node','Angular'];

    getAllCourses():string[]{
            return this.allCourses;
    }

    addANewCourse(coursetobeAdded){
            this.allCourses.push(coursetobeAdded)
    }
}
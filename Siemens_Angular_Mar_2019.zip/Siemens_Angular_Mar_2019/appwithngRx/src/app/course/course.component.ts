import { Component, OnInit } from '@angular/core';
import { CourseService } from './course.service';

@Component({
  selector: 'app-course',
  templateUrl: './course.component.html',
  styleUrls: ['./course.component.css']
})
export class CourseComponent implements OnInit {
    listOfCourses:string[] = [];
    newCourse:string =""; 
  constructor(public servObj:CourseService) {

    this.listOfCourses = this.servObj.getAllCourses();
   }

  ngOnInit() {
  }

  AddNewCourse(){
        this.servObj.addANewCourse(this.newCourse);
  }

}

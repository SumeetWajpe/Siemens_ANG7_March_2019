import { Product } from '../product.model';

export interface AppState{
    readonly products:Product[];
}
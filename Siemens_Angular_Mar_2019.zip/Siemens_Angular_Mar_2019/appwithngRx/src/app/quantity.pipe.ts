import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'quantity'
})
export class QuantityPipe implements PipeTransform {

  transform(value: any, args?: any,otherArgs?:any): any {

    if(value == 0){
      return "Item Out Of Stock !"
    }

    return value + " " + args + " " + otherArgs;
  }

}

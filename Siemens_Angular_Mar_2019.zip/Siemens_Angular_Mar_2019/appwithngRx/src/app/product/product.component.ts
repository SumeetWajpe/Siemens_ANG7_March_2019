import { Component, OnInit, Input, Output,EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { Product } from '../product.model';
import { Store } from '@ngrx/store';
import { AppState } from '../state/app.state';
import { IncrementLikes } from '../actions/app.actions';


@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProductComponent implements OnInit {
@Input() productdetails:Product = new Product();
@Input() productIndex:number;
@Output() changeLikes:EventEmitter<number> = new EventEmitter<number>()
@Output() deleteProduct:EventEmitter<number> = new EventEmitter<number>()

isFree:boolean=false;
isHighlighted:boolean=false;
  constructor(public store:Store<AppState>) { }

  ngOnInit() {
  }

  Incrementlikes(){
   // this.productdetails.likes++;
  //  this.productdetails.likes+=1; //??
  //  this.changeLikes.emit(this.productdetails.likes);
  this.productdetails.likes++;
  //this.store.dispatch(new IncrementLikes(this.productdetails.id))
  }

  DeleteTheProduct(){
    this.deleteProduct.emit(this.productIndex);
  }

}

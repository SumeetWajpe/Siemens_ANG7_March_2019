import { Action } from '@ngrx/store';


// IncrementLIkes -> {type:  , payload: }

export enum ActionTypes{
    IncrementLikes = '[Likes Product] Increment',
    DecrementLikes = '[Likes Product] Decrement',
}

export class IncrementLikes implements Action{
            readonly type = ActionTypes.IncrementLikes;
            constructor(public payload:number){

            }
}

export class DecrementLikes implements Action{
            readonly type = ActionTypes.DecrementLikes;
            constructor(public payload:number){

            }
}
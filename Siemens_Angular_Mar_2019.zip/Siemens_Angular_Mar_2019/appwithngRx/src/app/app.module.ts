import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatButtonModule, MatCheckboxModule} from '@angular/material';
import {HttpClientModule} from '@angular/common/http'

import { AppComponent } from './app.component';
import { ShoppingcartComponent } from './shoppingcart/shoppingcart.component';
import { ProductComponent } from './product/product.component';
import { QuantityPipe } from './quantity.pipe';
import { CourseComponent } from './course/course.component';
import { CourseService } from './course/course.service';
import { PostComponent } from './post/post.component';
import { PostsService } from './post/posts.service';
import { NewproducttemplatedrivenComponent } from './newproducttemplatedriven/newproducttemplatedriven.component';
import { NewproductmodeldrivenComponent } from './newproductmodeldriven/newproductmodeldriven.component';
import { ProductService } from './product/product.service';
import { StoreModule } from '@ngrx/store';
import { productsReducer } from './reducer/app.reducer';

@NgModule({
  declarations: [
    AppComponent,
    ShoppingcartComponent,
    ProductComponent,
    QuantityPipe,
    CourseComponent,
    PostComponent,
    NewproducttemplatedrivenComponent,
    NewproductmodeldrivenComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    BrowserAnimationsModule,
    MatCheckboxModule,
    HttpClientModule,
    ReactiveFormsModule,
    StoreModule.forRoot({products:productsReducer})
  ],
  providers:[CourseService,PostsService,ProductService],
  bootstrap: [AppComponent]
})
export class AppModule { }

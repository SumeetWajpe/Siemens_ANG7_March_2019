import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Product } from '../product.model';
import { ProductService } from '../product/product.service';
import { restrictTitleValidator } from './customeValidation';

@Component({
  selector: 'app-newproductmodeldriven',
  templateUrl: './newproductmodeldriven.component.html',
  styleUrls: ['./newproductmodeldriven.component.css']
})
export class NewproductmodeldrivenComponent implements OnInit {
   productForm:FormGroup;
   aNewProduct:Product = new Product();
  constructor(public servObj:ProductService) { }

  ngOnInit() {
    this.productForm = new FormGroup({
      'title':new FormControl(this.aNewProduct.title,[
        Validators.required,
        Validators.minLength(5),
        restrictTitleValidator(/laptop/i)
      ]),
      'price':new FormControl(this.aNewProduct.price),
      'rating':new FormControl(this.aNewProduct.rating),
      'quantity':new FormControl(this.aNewProduct.quantity),
      'ImageUrl':new FormControl(this.aNewProduct.ImageUrl),
      'likes':new FormControl(this.aNewProduct.likes)

    });// eof FormGroup
  }

  get f(){return this.productForm.controls}

  AddNewProduct(){
    // console.log(this.productForm.value);

    if(this.productForm.valid){
         this.servObj.insertNewProduct(this.productForm.value)
    }
  }

}

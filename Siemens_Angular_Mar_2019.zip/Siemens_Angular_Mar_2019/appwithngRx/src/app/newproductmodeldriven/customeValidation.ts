import { ValidatorFn, AbstractControl } from '@angular/forms';

export function restrictTitleValidator(productTitleReg:RegExp):ValidatorFn{
            return (control:AbstractControl): {[key:string]:any}  | null =>{
                        var restrictedName = productTitleReg.test(control.value);
            return restrictedName ? {'restrictedName':{value:control.value}}:null;
            }
}
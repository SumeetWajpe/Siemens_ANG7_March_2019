import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewproductmodeldrivenComponent } from './newproductmodeldriven.component';

describe('NewproductmodeldrivenComponent', () => {
  let component: NewproductmodeldrivenComponent;
  let fixture: ComponentFixture<NewproductmodeldrivenComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewproductmodeldrivenComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewproductmodeldrivenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
